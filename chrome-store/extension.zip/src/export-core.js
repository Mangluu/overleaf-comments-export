(function attachOverleafCommentsCore(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  root.OverleafCommentsCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCore() {
  "use strict";

  const SCHEMA_VERSION = "1.3";
  const TOOL_VERSION = "1.5.0-extension";
  const CONTEXT_BEFORE = 160;
  const CONTEXT_AFTER = 160;

  function normalizeWhitespace(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function toMilliseconds(value) {
    if (value === null || value === undefined || value === "" || typeof value === "boolean") {
      return null;
    }
    if (typeof value === "number" && Number.isFinite(value)) {
      return Math.trunc(value);
    }
    const text = String(value).trim();
    if (/^-?\d+$/.test(text)) {
      return Number.parseInt(text, 10);
    }
    const parsed = Date.parse(text);
    return Number.isNaN(parsed) ? null : parsed;
  }

  function isoTimestamp(value) {
    const milliseconds = toMilliseconds(value);
    if (!milliseconds) return null;
    try {
      // Written the way Python's datetime.isoformat() writes it, so the two
      // exports carry the same string for the same instant rather than two
      // spellings of it. toISOString gives 2023-11-14T22:13:20.000Z; Python
      // gives 2023-11-14T22:13:20+00:00, dropping the fraction when it is
      // zero and using six digits when it is not.
      //
      // Matching Python rather than the other way round, because the project
      // supports Python 3.10, whose fromisoformat cannot read the Z form, and
      // our own since.py parses these back.
      const iso = new Date(milliseconds).toISOString();
      const [main, fraction] = iso.split(".");
      const digits = String(fraction || "000Z").slice(0, -1);
      return digits === "000" ? `${main}+00:00` : `${main}.${digits}000+00:00`;
    } catch {
      return null;
    }
  }

  function displayTimestamp(value) {
    const iso = isoTimestamp(value);
    return iso ? `${iso.slice(0, 16).replace("T", " ")} UTC` : "?";
  }

  function userDetails(message) {
    const user = message?.user || {};
    const name = user.name || [user.first_name, user.last_name].filter(Boolean).join(" ") || null;
    return {
      id: String(message?.user_id || message?.userId || ""),
      name,
      email: user.email || null,
    };
  }

  function humanizeUser(user) {
    if (user?.name) return user.name;
    if (user?.email) {
      const local = user.email.split("@", 1)[0];
      const parts = local.replace(/[_-]/g, ".").split(".").filter(Boolean);
      if (parts.length >= 2 && parts.every((part) => /^[a-z]+$/i.test(part))) {
        return parts.map((part) => part[0].toUpperCase() + part.slice(1)).join(" ");
      }
      return local;
    }
    return (user?.id || "unknown").slice(0, 8);
  }

  function buildUserMap(rawThreads) {
    const users = {};
    for (const thread of Object.values(rawThreads || {})) {
      if (!thread || typeof thread !== "object") continue;
      for (const message of thread.messages || []) {
        const user = userDetails(message);
        if (!user.id) continue;
        users[user.id] ||= { id: user.id, name: null, email: null };
        if (user.name && !users[user.id].name) users[user.id].name = user.name;
        if (user.email && !users[user.id].email) users[user.id].email = user.email;
      }
    }
    return users;
  }

  function parseThreads(rawThreads, resolvedIds = []) {
    const resolved = new Set(Array.from(resolvedIds || [], String));
    const threads = {};
    for (const [threadId, rawThread] of Object.entries(rawThreads || {})) {
      if (!rawThread || typeof rawThread !== "object") continue;
      const messages = (rawThread.messages || []).map((message) => {
        const user = userDetails(message);
        return {
          id: String(message?.id || message?._id || ""),
          content: String(message?.content || ""),
          timestampMs: toMilliseconds(message?.timestamp) || 0,
          editedAtMs: toMilliseconds(message?.edited_at),
          user,
        };
      });
      threads[threadId] = {
        id: threadId,
        messages,
        resolved: Boolean(rawThread.resolved || resolved.has(threadId)),
        resolvedAtMs: toMilliseconds(rawThread.resolved_at),
        resolvedByUserId: rawThread.resolved_by_user_id
          ? String(rawThread.resolved_by_user_id)
          : null,
      };
    }
    return threads;
  }

  function flattenFiles(filesRoot) {
    const output = [];

    function walk(node, parentPath) {
      if (!node) return;
      if (Array.isArray(node)) {
        for (const child of node) walk(child, parentPath);
        return;
      }
      if (typeof node !== "object") return;

      if (node.rootFolder) {
        walk(node.rootFolder, parentPath);
      }

      for (const doc of node.docs || []) {
        const id = doc?._id || doc?.id || doc?.doc_id;
        const name = doc?.name;
        if (id && name) output.push({ docId: String(id), pathname: `${parentPath}${name}` });
      }

      for (const folder of node.folders || []) {
        const name = folder?.name || "";
        const nextPath = name && name !== "rootFolder" ? `${parentPath}${name}/` : parentPath;
        walk(folder, nextPath);
      }

      if (Array.isArray(node.children)) {
        if (node.type === "folder") {
          const name = node.name || "";
          const nextPath = name && name !== "rootFolder" ? `${parentPath}${name}/` : parentPath;
          for (const child of node.children) walk(child, nextPath);
        } else {
          for (const child of node.children) walk(child, parentPath);
        }
      }

      const kind = node.type || node.kind;
      const id = node._id || node.id || node.doc_id;
      if (id && node.name && kind === "doc") {
        output.push({ docId: String(id), pathname: `${parentPath}${node.name}` });
      }
    }

    walk(filesRoot, "");
    const seen = new Set();
    return output.filter((entry) => {
      const key = `${entry.docId}\u0000${entry.pathname}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function documentRanges(payload) {
    const docs = Array.isArray(payload)
      ? payload
      : payload && typeof payload === "object"
        ? payload.docs || payload.ranges || []
        : [];
    const output = [];
    for (const entry of docs) {
      if (!entry || typeof entry !== "object") continue;
      const docId = entry.id || entry._id || entry.doc_id;
      if (!docId) continue;
      const ranges = entry.ranges || {};
      output.push({
        docId: String(docId),
        comments: Array.isArray(ranges.comments) ? ranges.comments : [],
        changes: Array.isArray(ranges.changes) ? ranges.changes : [],
      });
    }
    return output;
  }

  function buildLineStarts(text) {
    const starts = [0];
    for (let index = 0; index < text.length; index += 1) {
      if (text[index] === "\n") starts.push(index + 1);
    }
    return starts;
  }

  function upperBound(values, target) {
    let low = 0;
    let high = values.length;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      if (values[middle] <= target) low = middle + 1;
      else high = middle;
    }
    return low;
  }

  function offsetToLineColumn(lineStarts, rawOffset) {
    const offset = Math.max(0, Number(rawOffset) || 0);
    const line = Math.max(1, upperBound(lineStarts, offset));
    return { line, column: offset - lineStarts[line - 1] };
  }

  function resolveAnchor(text, lineStarts, rawOffset, anchoredText, searchWindow = 200) {
    const offset = Math.max(0, Number(rawOffset) || 0);
    const anchor = String(anchoredText || "");
    if (anchor && text.slice(offset, offset + anchor.length) === anchor) {
      return { offset, ...offsetToLineColumn(lineStarts, offset), stale: false };
    }

    if (anchor) {
      const low = Math.max(0, offset - searchWindow);
      const high = Math.min(text.length, offset + searchWindow + anchor.length);
      const nearby = text.indexOf(anchor, low);
      if (nearby !== -1 && nearby <= high - anchor.length) {
        return { offset: nearby, ...offsetToLineColumn(lineStarts, nearby), stale: false };
      }
      const anywhere = text.indexOf(anchor);
      if (anywhere !== -1) {
        return { offset: anywhere, ...offsetToLineColumn(lineStarts, anywhere), stale: true };
      }
    }

    // The bounded one, not the raw one. An offset past the end slices to
    // nothing, so the context reads as though there were none, and it
    // contradicts the line and column right beside it, which are bounded.
    const bounded = Math.min(offset, Math.max(0, text.length - 1));
    return { offset: bounded, ...offsetToLineColumn(lineStarts, bounded), stale: true };
  }


  // ---- Reading a paper the way LaTeX reads it -----------------------------
  //
  // A paper split across files is read in the order the root document pulls
  // the pieces in, and two things depend on that order rather than on any one
  // file. Section headings, because main.tex can say \section{Results} and
  // then \input{results-body}, so read on its own the included file has no
  // heading at all. And figure and table numbers, because LaTeX counts them
  // straight through: counted per file they restart, and a comment on
  // Figure 2 gets reported as Figure 1, which is worse than saying nothing.
  //
  // This mirrors overleaf_comments_export/docorder.py and the float half of
  // sections.py. The two are compared against each other by a shared fixture
  // in tests/test_schema_parity.py, which is what keeps them honest.

  const includeRe = () => /\\(?:input|include|subfile)\s*\{([^}]*)\}/g;

  function stripComments(text) {
    // Blank out commented-out text, keeping offsets so nothing shifts. A
    // commented \input is not read by LaTeX and must not be read here.
    return text.split("\n").map((line) => {
      for (let i = 0; i < line.length; i += 1) {
        if (line[i] === "%" && (i === 0 || line[i - 1] !== "\\")) {
          return line.slice(0, i) + " ".repeat(line.length - i);
        }
      }
      return line;
    }).join("\n");
  }

  function candidates(ref) {
    let name = String(ref || "").replace(/\\/g, "/").trim();
    while (name.startsWith("./")) name = name.slice(2);
    if (!name) return [];
    return name.endsWith(".tex") ? [name] : [`${name}.tex`, name];
  }

  function matchInclude(ref, available) {
    for (const name of candidates(ref)) {
      if (Object.prototype.hasOwnProperty.call(available, name)) return name;
    }
    // A project can say \input{intro} for a file the tree calls
    // sections/intro.tex. Match on the tail, but only when unambiguous.
    for (const name of candidates(ref)) {
      const hits = Object.keys(available).filter(
        (p) => p === name || p.endsWith(`/${name}`));
      if (hits.length === 1) return hits[0];
    }
    return null;
  }

  function findIncludes(text) {
    return Array.from(stripComments(text).matchAll(includeRe()),
                      (m) => String(m[1] || "").trim()).filter(Boolean);
  }

  function resolveInclude(ref, available) {
    return matchInclude(ref, available);
  }

  function flattenProject(root, texts) {
    // Splice the whole project into the single document LaTeX reads, and
    // record where each piece landed. Whole files are not enough: \input
    // happens at a point, so a file pulled in halfway through the root
    // inherits only the headings above that point.
    const parts = [];
    const marks = [];
    const missing = [];
    const depth = new Set();
    let total = 0;

    function emit(path, text, lo, hi) {
      marks.push({ path, lo, at: total });
      const chunk = text.slice(lo, hi);
      parts.push(chunk);
      total += chunk.length;
    }

    function walk(path) {
      if (depth.has(path)) return;      // a ring of includes; LaTeX fails too
      depth.add(path);
      const text = texts[path];
      const stripped = stripComments(text);
      let cursor = 0;
      // Collected before recursing: walk() calls itself from inside this
      // loop, and a shared /g regex would have its lastIndex moved underneath.
      for (const m of [...stripped.matchAll(includeRe())]) {
        const ref = String(m[1] || "").trim();
        if (!ref) continue;
        emit(path, text, cursor, m.index);
        cursor = m.index + m[0].length;
        const target = matchInclude(ref, texts);
        if (target === null) missing.push(ref);
        else walk(target);
      }
      emit(path, text, cursor, text.length);
      depth.delete(path);
    }

    if (!Object.prototype.hasOwnProperty.call(texts, root)) {
      return { joined: "", marks: [], missing: [root] };
    }
    walk(root);
    return { joined: parts.join(""), marks, missing };
  }

  function locateInJoined(marks, path, offset) {
    let best = null;
    for (const mark of marks) {
      if (mark.path === path && mark.lo <= offset) {
        if (best === null || mark.lo > best.lo) best = mark;
      }
    }
    return best === null ? null : best.at + (offset - best.lo);
  }


  // ---- Figures and tables -------------------------------------------------
  //
  // So a comment on a caption can say "Figure 3" rather than a line number.
  // figure* and table* share their counter with the unstarred form, which is
  // why the star is stripped rather than treated as a separate kind. Mirrors
  // the float half of sections.py.

  // Built fresh on every use. A /g regex carries lastIndex, so sharing one
  // between a loop and anything that loop calls corrupts both: captionAndLabel
  // iterating the nested-float pattern while matchingEnd reset it meant the
  // loop never advanced and the process ran out of memory.
  const floatBeginRe = () => /\\begin\{(figure|table)\*?\}/g;
  // Nested floats do exist: subfigure inside figure, a table inside a figure.
  const anyBeginRe = () => /\\begin\{(?:figure|table|subfigure|subtable)\*?\}/g;
  const anyEndRe = () => /\\end\{(?:figure|table|subfigure|subtable)\*?\}/g;
  const captionRe = () => /\\caption\*?\s*(?:\[[^\]]*\])?\s*\{/g;
  const labelRe = () => /\\label\s*\{([^}]*)\}/g;

  function isCommentedOut(text, pos) {
    // Walk back to the start of the line: a % before this position, not
    // itself escaped, means LaTeX never sees any of it.
    const lineStart = text.lastIndexOf("\n", pos - 1) + 1;
    for (let i = lineStart; i < pos; i += 1) {
      if (text[i] === "%" && (i === lineStart || text[i - 1] !== "\\")) return true;
    }
    return false;
  }

  function balancedArgument(text, openBrace) {
    let depth = 0;
    for (let i = openBrace; i < text.length; i += 1) {
      const ch = text[i];
      if (ch === "\\") { i += 1; continue; }
      if (ch === "{") depth += 1;
      else if (ch === "}") {
        depth -= 1;
        if (depth === 0) return text.slice(openBrace + 1, i);
      }
    }
    return text.slice(openBrace + 1);
  }

  function matchingEnd(text, afterBegin) {
    // Where this float closes, counting nested floats on the way.
    let depth = 1;
    let i = afterBegin;
    const begin = anyBeginRe();
    const end = anyEndRe();
    while (i < text.length && depth > 0) {
      begin.lastIndex = i;
      end.lastIndex = i;
      const nextBegin = begin.exec(text);
      const nextEnd = end.exec(text);
      if (!nextEnd) return text.length;
      if (nextBegin && nextBegin.index < nextEnd.index) {
        depth += 1;
        i = nextBegin.index + nextBegin[0].length;
      } else {
        depth -= 1;
        i = nextEnd.index + nextEnd[0].length;
      }
    }
    return i;
  }

  function captionAndLabel(body) {
    // The float's own caption and label, ignoring any belonging to something
    // nested inside it. A subfigure has its own caption, and that is not the
    // caption of the float being named.
    const nested = [];
    for (const m of body.matchAll(anyBeginRe())) {
      nested.push([m.index, matchingEnd(body, m.index + m[0].length)]);
    }
    const outside = (pos) => !nested.some(([a, b]) => a < pos && pos < b);

    let caption = null;
    for (const m of body.matchAll(captionRe())) {
      if (outside(m.index) && !isCommentedOut(body, m.index)) {
        caption = balancedArgument(body, m.index + m[0].length - 1)
          .split(/\s+/).filter(Boolean).join(" ");
        break;
      }
    }
    let label = null;
    for (const m of body.matchAll(labelRe())) {
      if (outside(m.index) && !isCommentedOut(body, m.index)) {
        label = String(m[1] || "").trim();
        break;
      }
    }
    return { caption, label };
  }

  function findFloats(text, lineStarts) {
    // Only captioned floats take a number, because LaTeX only steps the
    // counter when there is a caption. An uncaptioned one is still recorded,
    // so a comment inside it can say it is in a figure without saying which.
    const floats = [];
    const counters = { figure: 0, table: 0 };
    for (const m of text.matchAll(floatBeginRe())) {
      if (isCommentedOut(text, m.index)) continue;
      if (floats.some((f) => f.start < m.index && m.index < f.end)) continue;
      const kind = m[1];
      const end = matchingEnd(text, m.index + m[0].length);
      const { caption, label } = captionAndLabel(text.slice(m.index + m[0].length, end));
      if (caption !== null) counters[kind] += 1;
      floats.push({
        kind,
        number: caption === null ? null : counters[kind],
        caption,
        label,
        start: m.index,
        end,
        line: offsetToLineColumn(lineStarts, m.index).line,
      });
    }
    return floats;
  }

  function enclosingFloat(floats, offset) {
    // The float containing this position. findFloats never records a float
    // inside another, so there is only ever one, and taking the first keeps
    // this identical to enclosing_float in sections.py rather than merely
    // equivalent to it.
    for (const f of floats) {
      if (f.start <= offset && offset < f.end) return f;
    }
    return null;
  }

  function findHeadings(text, lineStarts) {
    const headings = [];
    const levels = {
      part: -1,
      chapter: 0,
      section: 1,
      subsection: 2,
      subsubsection: 3,
      paragraph: 4,
    };
    const headingPattern = /^\s*\\(section|subsection|subsubsection|chapter|paragraph|part)\*?\s*(?:\[[^\]]*\])?\s*\{(.*?)\}/gm;
    for (const match of text.matchAll(headingPattern)) {
      headings.push({
        line: upperBound(lineStarts, match.index),
        level: levels[match[1]] ?? 99,
        text: match[2].trim(),
      });
    }

    const pseudoPattern = /^\s*\\(?:begin\{(abstract|titlepage)\}|(title|maketitle|tableofcontents|frontmatter|mainmatter|backmatter|appendix))(?:\s*\{([^}]*)\})?/gm;
    for (const match of text.matchAll(pseudoPattern)) {
      const environment = match[1];
      const command = match[2];
      const argument = (match[3] || "").trim();
      let label = null;
      if (environment === "abstract") label = "Abstract";
      else if (environment === "titlepage") label = "Title page";
      else if (command === "title") label = argument ? `Title: ${argument}` : "Title";
      else if (command === "maketitle") label = "Title block";
      else if (command === "tableofcontents") label = "Table of contents";
      else if (command === "frontmatter") label = "Front matter";
      else if (command === "mainmatter") label = "Main matter";
      else if (command === "backmatter") label = "Back matter";
      else if (command === "appendix") label = "Appendix";
      if (label) {
        headings.push({ line: upperBound(lineStarts, match.index), level: 1, text: label });
      }
    }

    return headings.sort((left, right) => left.line - right.line || left.level - right.level);
  }

  function nearestHeading(headings, line) {
    const enclosing = new Map();
    for (const heading of headings) {
      if (heading.line > line) break;
      enclosing.set(heading.level, heading);
      for (const level of Array.from(enclosing.keys())) {
        if (level > heading.level) enclosing.delete(level);
      }
    }
    return Array.from(enclosing.keys())
      .sort((left, right) => left - right)
      .map((level) => enclosing.get(level).text)
      .join(" > ") || null;
  }

  function extractContext(text, offset, anchoredText, line) {
    if (!text) {
      return {
        line,
        before: "",
        anchor: anchoredText || "",
        after: "",
        truncatedBefore: false,
        truncatedAfter: false,
      };
    }
    const anchor = String(anchoredText || "");
    let end = offset + anchor.length;
    let actualAnchor = anchor;
    if (!anchor || text.slice(offset, end) !== anchor) {
      if (!anchor) {
        actualAnchor = text.slice(offset, offset + Math.min(40, Math.max(0, text.length - offset)));
        end = offset + actualAnchor.length;
      }
    }
    return {
      line,
      before: normalizeWhitespace(text.slice(Math.max(0, offset - CONTEXT_BEFORE), offset)),
      anchor: normalizeWhitespace(actualAnchor),
      after: normalizeWhitespace(text.slice(end, Math.min(text.length, end + CONTEXT_AFTER))),
      truncatedBefore: offset > CONTEXT_BEFORE,
      truncatedAfter: end < text.length - CONTEXT_AFTER,
    };
  }

  function deletionContext(text, offset, deletedText, line) {
    const bounded = Math.max(0, Math.min(Number(offset) || 0, text.length));
    return {
      line,
      before: normalizeWhitespace(text.slice(Math.max(0, bounded - CONTEXT_BEFORE), bounded)),
      anchor: normalizeWhitespace(deletedText),
      after: normalizeWhitespace(text.slice(bounded, bounded + CONTEXT_AFTER)),
      truncatedBefore: bounded > CONTEXT_BEFORE,
      truncatedAfter: bounded + CONTEXT_AFTER < text.length,
    };
  }

  function serializeThread(thread, userMap) {
    const messages = [...thread.messages].sort((left, right) => left.timestampMs - right.timestampMs);
    const resolver = thread.resolvedByUserId ? userMap[thread.resolvedByUserId] : null;
    return {
      id: thread.id,
      resolved: thread.resolved,
      resolved_at: isoTimestamp(thread.resolvedAtMs),
      resolved_by: resolver || (thread.resolvedByUserId ? { id: thread.resolvedByUserId, name: null, email: null } : null),
      reply_count: Math.max(0, messages.length - 1),
      messages: messages.map((message, index) => ({
        id: message.id,
        role: index === 0 ? "comment" : "reply",
        reply_index: index === 0 ? null : index - 1,
        user: message.user,
        content: message.content,
        timestamp: isoTimestamp(message.timestampMs),
        edited_at: isoTimestamp(message.editedAtMs),
      })),
    };
  }

  function inlineContext(context, anchoredText) {
    if (!context) return anchoredText ? `> **▸${anchoredText}◂**` : "> _(anchor text unavailable)_";
    const before = context.before.length > 70 ? context.before.slice(-70).trimStart() : context.before;
    const after = context.after.length > 70 ? context.after.slice(0, 70).trimEnd() : context.after;
    const lead = context.truncatedBefore || context.before.length > 70 ? "…" : "";
    const tail = context.truncatedAfter || context.after.length > 70 ? "…" : "";
    return `> ${lead}${before}${before ? " " : ""}**▸${context.anchor || anchoredText || ""}◂**${after ? ` ${after}` : ""}${tail}`;
  }

  function emitMessages(lines, thread, indent = "") {
    const messages = [...(thread?.messages || [])].sort((left, right) => left.timestampMs - right.timestampMs);
    if (!messages.length) {
      lines.push(`${indent}- _(no messages)_`);
      return;
    }
    messages.forEach((message, index) => {
      const who = humanizeUser(message.user);
      const when = displayTimestamp(message.timestampMs);
      const edited = message.editedAtMs ? " _(edited)_" : "";
      const prefix = index === 0 ? `${indent}- ` : `${indent}  - ↳ `;
      const body = String(message.content || "").trim();
      if (body.includes("\n")) {
        lines.push(`${prefix}**${who}** · ${when}${edited}:`);
        for (const bodyLine of body.split(/\r?\n/)) lines.push(`${indent}    > ${bodyLine}`);
      } else {
        lines.push(`${prefix}**${who}** · ${when}${edited}: ${body}`);
      }
    });
  }

  const REPORT_COPY = {
    zh: {
      title: "Overleaf 评论 — {title}",
      summary: "摘要",
      threads: "**讨论：** {total}（{open} 个未解决，{resolved} 个已解决）",
      changes: "**修订记录：** {count}",
      files: "**文件：** {count}",
      reviewers: "**评论者：** {count}",
      noSection: "_(无所属章节)_",
      line: "第 {line} 行",
      resolved: "已解决",
      open: "未解决",
      reply: "{count} 条回复",
      commentedAt: "评论时间：{time}",
      trackedChanges: "修订记录",
      insertion: "插入",
      deletion: "删除",
      changedAt: "修订时间：{time}",
      orphanTitle: "无法定位锚点的讨论",
      orphanHelp: "_Overleaf 返回了这些讨论，但无法将它们定位到当前源文件文本。_",
      thread: "讨论",
      responseTitle: "评论回复信 — {title}",
      noOpen: "_没有发现带锚点的未解决评论。_",
      referringTo: "**对应原文：**",
      comment: "**评论：**",
      commentTime: "**评论时间：** {time}",
      response: "**回复：**",
      changeMade: "**所作修改：**",
      changeTodo: "_待填写 — 说明修改内容和位置。_",
    },
    en: {
      title: "Overleaf comments — {title}",
      summary: "Summary",
      threads: "**Threads:** {total} ({open} open, {resolved} resolved)",
      changes: "**Tracked changes:** {count}",
      files: "**Files:** {count}",
      reviewers: "**Reviewers:** {count}",
      noSection: "_(no enclosing section)_",
      line: "Line {line}",
      resolved: "resolved",
      open: "open",
      reply: "{count} {label}",
      commentedAt: "Commented: {time}",
      trackedChanges: "Tracked changes",
      insertion: "insertion",
      deletion: "deletion",
      changedAt: "Changed: {time}",
      orphanTitle: "Threads without resolvable anchors",
      orphanHelp: "_These discussions were returned by Overleaf but could not be mapped to live source text._",
      thread: "Thread",
      responseTitle: "Response to comments — {title}",
      noOpen: "_No open anchored comments were found._",
      referringTo: "**Referring to:**",
      comment: "**Comment:**",
      commentTime: "**Comment time:** {time}",
      response: "**Response:**",
      changeMade: "**Change made:**",
      changeTodo: "_TODO — describe what changed and where._",
    },
  };

  function reportText(payload, key, replacements = {}) {
    const language = payload.report_language === "zh" ? "zh" : "en";
    let value = REPORT_COPY[language][key] || REPORT_COPY.en[key] || key;
    for (const [name, replacement] of Object.entries(replacements)) {
      value = value.replaceAll(`{${name}}`, String(replacement));
    }
    return value;
  }

  function renderMarkdown(payload) {
    const summary = payload.summary;
    const lines = [
      "---",
      `schema_version: ${payload.schema_version}`,
      `tool_version: ${payload.tool_version}`,
      `project_id: ${payload.project.id}`,
      `project_title: ${JSON.stringify(payload.project.title)}`,
      `pulled_at: ${payload.pulled_at}`,
      `thread_count: ${summary.thread_count}`,
      `open_count: ${summary.open_count}`,
      `resolved_count: ${summary.resolved_count}`,
      `tracked_change_count: ${summary.tracked_change_count}`,
      `stale_anchor_count: ${summary.stale_anchor_count}`,
      `file_count: ${summary.file_count}`,
      `reviewer_count: ${summary.reviewer_count}`,
      "companion_json: comments.json",
      "companion_agents: agents.md",
      "---",
      "",
      `# ${reportText(payload, "title", { title: payload.project.title })}`,
      "",
      `## ${reportText(payload, "summary")}`,
      "",
      `- ${reportText(payload, "threads", { total: summary.thread_count, open: summary.open_count, resolved: summary.resolved_count })}`,
      `- ${reportText(payload, "changes", { count: summary.tracked_change_count })}`,
      `- ${reportText(payload, "files", { count: summary.file_count })}`,
      `- ${reportText(payload, "reviewers", { count: summary.reviewer_count })}`,
      "",
    ];

    const commentsByPath = new Map();
    for (const comment of payload.comments) {
      if (!commentsByPath.has(comment.pathname)) commentsByPath.set(comment.pathname, []);
      commentsByPath.get(comment.pathname).push(comment);
    }
    const changesByPath = new Map();
    for (const change of payload.tracked_changes) {
      if (!changesByPath.has(change.pathname)) changesByPath.set(change.pathname, []);
      changesByPath.get(change.pathname).push(change);
    }
    const paths = Array.from(new Set([...commentsByPath.keys(), ...changesByPath.keys()])).sort();

    for (const pathname of paths) {
      lines.push(`## ${pathname}`, "");
      let previousHeading = null;
      for (const comment of commentsByPath.get(pathname) || []) {
        const heading = comment.nearest_heading || reportText(payload, "noSection");
        if (heading !== previousHeading) {
          lines.push(`### § ${heading}`, "");
          previousHeading = heading;
        }
        const thread = payload.threads[comment.thread_id];
        const replies = thread?.reply_count || 0;
        const status = reportText(payload, thread?.resolved ? "resolved" : "open");
        const stale = comment.stale ? " · ⚠ stale" : "";
        const quote = normalizeWhitespace(comment.anchored_text);
        const replyLabel = payload.report_language === "zh"
          ? reportText(payload, "reply", { count: replies })
          : reportText(payload, "reply", { count: replies, label: replies === 1 ? "reply" : "replies" });
        lines.push(`**${reportText(payload, "line", { line: comment.line })}**`, "", inlineContext(comment.context, quote), "");
        lines.push(
          `**${comment.short_id}** _${status}${replies ? ` · ${replyLabel}` : ""}${stale}_ — “${quote}”`,
          `- ${reportText(payload, "commentedAt", { time: displayTimestamp(comment.created_at) })}`
        );
        emitMessages(lines, thread);
        lines.push("");
      }

      const changes = changesByPath.get(pathname) || [];
      if (changes.length) lines.push(`### § ${reportText(payload, "trackedChanges")}`, "");
      for (const change of changes) {
        const sign = change.kind === "insertion" ? "+" : "-";
        lines.push(
          `**${change.short_id}** _${reportText(payload, change.kind)}_ — ${reportText(payload, "line", { line: change.line })} — ${humanizeUser(change.user)} · ${displayTimestamp(change.timestamp)}`,
          `- ${reportText(payload, "changedAt", { time: displayTimestamp(change.timestamp) })}`,
          `- \`${sign} ${normalizeWhitespace(change.content)}\``,
          ""
        );
      }
    }

    if (payload.orphan_thread_ids.length) {
      lines.push(`## ${reportText(payload, "orphanTitle")}`, "", reportText(payload, "orphanHelp"), "");
      for (const threadId of payload.orphan_thread_ids) {
        const thread = payload.threads[threadId];
        lines.push(`- **${reportText(payload, "thread")} \`${threadId.slice(0, 8)}…\`** _${reportText(payload, thread.resolved ? "resolved" : "open")}_`);
        emitMessages(lines, thread, "  ");
        lines.push("");
      }
    }

    return `${lines.join("\n").trimEnd()}\n`;
  }

  function renderJsonLines(payload) {
    const records = [];
    for (const comment of payload.comments) {
      records.push({
        schema_version: payload.schema_version,
        type: "comment",
        project: payload.project,
        ...comment,
        thread: payload.threads[comment.thread_id] || null,
      });
    }
    for (const threadId of payload.orphan_thread_ids) {
      records.push({
        schema_version: payload.schema_version,
        type: "orphan_thread",
        project: payload.project,
        thread: payload.threads[threadId],
      });
    }
    return records.map((record) => JSON.stringify(record)).join("\n") + (records.length ? "\n" : "");
  }

  function renderAgentsBrief(payload, markdownName) {
    // Deliberately the same brief the Python export writes. It is the file
    // that tells an assistant how to read the other two, so the two exports
    // saying different things would defeat the point of sharing a schema
    // version.
    return `# Agent brief - Overleaf comments for ${payload.project.title}

You are reading an Overleaf comment export produced by the
overleaf-comments-export browser extension. Two files in this folder are
relevant:

- \`${markdownName}\` - human-readable Markdown, with YAML front-matter and
  comments grouped by file, then section, then line. Every comment has a
  stable short ID like \`C001\`, assigned in file then line order. The
  Markdown is the canonical user-facing view.
- \`comments.json\` - the same data in structured form. Use this when you need
  to enumerate, filter, or programmatically address comments.

## JSON schema (key parts)

- \`schema_version\` (string)
- \`project\` - \`{ id, title }\`
- \`summary\` - counts (threads, open/resolved, tracked changes, stale, files,
  reviewers)
- \`threads\` - \`{ "<thread_id>": { id, resolved, resolved_at,
  resolved_by_user_id, messages: [...] } }\` - stored once at top level, not
  duplicated inside each comment.
- \`files\` - list of \`{ pathname, doc_id, comment_count, change_count,
  comment_short_ids, change_short_ids }\`
- \`comments\` - list of \`{ short_id, thread_id, doc_id, pathname, line, col,
  offset, nearest_heading, anchored_text, stale, context }\`. To get the
  discussion, look up \`threads[thread_id]\`.
- \`tracked_changes\` - list of \`{ short_id, id, doc_id, pathname, kind
  (insertion|deletion), content, line, col, offset, nearest_heading, user,
  timestamp, context }\`
- \`orphan_thread_ids\` - IDs of threads that do not anchor to live source.

\`context\` is a compact char-window snippet: \`before\`, \`anchor\`, \`after\`,
with \`truncated_before\`/\`truncated_after\` flags.

## How to address comments

- Refer to comments by \`short_id\`, for example "C014", not by \`thread_id\`.
- Each thread's FIRST message is the reviewer's actual ask. Later messages are
  follow-up discussion, often between co-authors. Answer the ask, taking the
  discussion into account; do not re-litigate sub-points the replies already
  settled.
- For each open comment, propose an edit to the .tex source. If the comment is
  a question, answer it; if it is a request, attempt the change.
- Stale comments (\`stale: true\`) may not point to the current location in the
  doc. Use \`anchored_text\` and \`nearest_heading\` to find the right spot.
- Tracked changes (\`T001\`-prefixed) are not comment threads; they are
  insertions and deletions someone made with Track Changes enabled. Treat them
  as suggested edits to accept, reject, or modify.

## What you do NOT have

- The full \`.tex\` source of the paper. You only see a short window around each
  anchor. If you need more context, ask the user to share the relevant \`.tex\`
  file.
- The ability to push edits back to Overleaf. Output any proposed edits as
  diffs or rewrites; the user will apply them.

Project ID for reference: \`${payload.project.id}\`.
`;
  }

  function renderResponseLetter(payload) {
    const lines = [`# ${reportText(payload, "responseTitle", { title: payload.project.title })}`, ""];
    const openComments = payload.comments.filter((comment) => !payload.threads[comment.thread_id]?.resolved);
    if (!openComments.length) {
      lines.push(reportText(payload, "noOpen"), "");
      return lines.join("\n");
    }
    for (const comment of openComments) {
      const thread = payload.threads[comment.thread_id];
      const rootMessage = thread?.messages?.[0];
      lines.push(
        `## ${comment.short_id} — ${comment.pathname}:${comment.line}`,
        "",
        `${reportText(payload, "referringTo")} “${normalizeWhitespace(comment.anchored_text)}”`,
        "",
        reportText(payload, "commentTime", { time: displayTimestamp(comment.created_at) }),
        "",
        reportText(payload, "comment"),
        "",
        `> ${String(rootMessage?.content || "").replace(/\r?\n/g, "\n> ")}`,
        "",
        reportText(payload, "response"),
        "",
        "_TODO_",
        "",
        reportText(payload, "changeMade"),
        "",
        reportText(payload, "changeTodo"),
        ""
      );
    }
    return `${lines.join("\n").trimEnd()}\n`;
  }

  function applyDocumentOrder({ anchored, trackedChanges, docTexts, docIdToPath, rootDocId }) {
    const rootPath = docIdToPath[rootDocId];
    if (!rootPath) return;

    const texts = {};
    for (const [docId, text] of Object.entries(docTexts)) {
      const path = docIdToPath[docId];
      if (path && typeof text === "string") texts[path] = text;
    }
    if (!Object.prototype.hasOwnProperty.call(texts, rootPath)) return;

    const { joined, marks, missing } = flattenProject(rootPath, texts);
    if (!joined) return;

    if (missing.length) {
      for (const item of anchored) {
        if (item.enclosingFloat) item.enclosingFloat.number = null;
      }
      return;
    }
    if (new Set(marks.map((m) => m.path)).size < 2) return;  // one file: already right

    const lineStarts = buildLineStarts(joined);
    const floats = findFloats(joined, lineStarts);
    const headings = findHeadings(joined, lineStarts);

    const relocate = (item) => {
      const path = docIdToPath[item.docId];
      return path ? locateInJoined(marks, path, item.offset) : null;
    };
    for (const item of anchored) {
      const at = relocate(item);
      if (at === null) continue;
      item.enclosingFloat = enclosingFloat(floats, at);
      item.nearestHeading = nearestHeading(headings, offsetToLineColumn(lineStarts, at).line);
    }
    for (const change of trackedChanges) {
      const at = relocate(change);
      if (at !== null) {
        change.nearestHeading = nearestHeading(headings, offsetToLineColumn(lineStarts, at).line);
      }
    }
  }


  // ---- The export as rows, for a spreadsheet -------------------------------
  //
  // Mirrors sheets.py. A sheet is flat and the data is not, so three sheets
  // keyed on the short id: one row per comment, one per reply, one per
  // tracked change. One flat table would force a choice between losing the
  // replies and repeating every comment's details on every reply row, and the
  // second makes filtering lie to you.

  const COMMENT_COLUMNS = [
    "Comment", "File", "Line", "Section", "Figure or table", "Commented on",
    "Author", "Raised", "Status", "Replies", "Comment text",
  ];
  const REPLY_COLUMNS = ["Comment", "Reply", "Author", "Written", "Reply text"];
  const CHANGE_COLUMNS = [
    "Change", "File", "Line", "Section", "Kind", "Author", "When", "Text",
  ];

  function floatLabel(enclosing) {
    if (!enclosing) return "";
    const kindRaw = String(enclosing.kind || "");
    const kind = kindRaw ? kindRaw[0].toUpperCase() + kindRaw.slice(1) : "";
    if (enclosing.number) return `${kind} ${enclosing.number}`;
    if (enclosing.caption) {
      return enclosing.label
        ? `${kind} “${enclosing.caption}” (${enclosing.label})`
        : `${kind} “${enclosing.caption}”`;
    }
    return `${kind} (unnumbered)`;
  }

  function personName(user) {
    const u = user || {};
    return String(u.name || u.email || u.id || "");
  }

  function threadMessages(thread) {
    if (!thread || typeof thread !== "object") return [];
    return (thread.messages || []).filter((m) => m && typeof m === "object");
  }

  function capitalise(value) {
    const s = String(value || "");
    return s ? s[0].toUpperCase() + s.slice(1) : "";
  }

  function buildSheetRows(payload) {
    const threads = payload.threads || {};
    const comments = [COMMENT_COLUMNS.slice()];
    const replies = [REPLY_COLUMNS.slice()];

    for (const c of payload.comments || []) {
      const msgs = threadMessages(threads[c.thread_id]);
      const first = msgs[0] || {};
      const resolved = Boolean((threads[c.thread_id] || {}).resolved);
      comments.push([
        c.short_id || "",
        c.pathname || "",
        c.line || "",
        c.nearest_heading || "",
        floatLabel(c.enclosing_float),
        c.anchored_text || "",
        personName(first.user),
        first.timestamp || "",
        resolved ? "Resolved" : "Open",
        Math.max(0, msgs.length - 1),
        first.content || "",
      ]);
      msgs.slice(1).forEach((m, i) => {
        replies.push([
          c.short_id || "", i + 1, personName(m.user),
          m.timestamp || "", m.content || "",
        ]);
      });
    }

    const changes = [CHANGE_COLUMNS.slice()];
    for (const ch of payload.tracked_changes || []) {
      changes.push([
        ch.short_id || "", ch.pathname || "", ch.line || "",
        ch.nearest_heading || "", capitalise(ch.kind),
        personName(ch.user), ch.timestamp || "", ch.content || "",
      ]);
    }

    return { Comments: comments, Replies: replies, "Tracked changes": changes };
  }


  // ---- What changed since the last export ---------------------------------
  //
  // Reviews arrive in waves, and the second export of a paper is mostly
  // comments you read last week. Mirrors since.py, which does this by reading
  // the previous comments.json out of the folder. There is no folder to read
  // here, so the popup keeps a small snapshot of the last export in extension
  // storage and hands it back on the next run.
  //
  // Identity is the thread id, never the short id. Short ids go in file then
  // line order, so one comment added near the top renumbers everything below
  // it and a diff keyed on them would report the whole paper as new.

  function sinceSnapshot(payload) {
    // Only what the comparison reads. Storing the whole payload would put a
    // quarter of a megabyte per project into a quota shared with everything
    // else the extension keeps.
    return {
      project: payload.project,
      pulled_at: payload.pulled_at,
      filters_applied: payload.filters_applied || {},
      threads: Object.fromEntries(Object.entries(payload.threads || {}).map(
        ([id, t]) => [id, {
          resolved: Boolean(t.resolved),
          resolved_by: t.resolved_by || null,
          reply_count: t.reply_count || 0,
          messages: (t.messages || []).map((m) => ({
            id: m.id, content: m.content, timestamp: m.timestamp, user: m.user,
          })),
        }])),
      comments: (payload.comments || []).map((c) => ({
        short_id: c.short_id, thread_id: c.thread_id, pathname: c.pathname,
        line: c.line, nearest_heading: c.nearest_heading,
        enclosing_float: c.enclosing_float, anchored_text: c.anchored_text,
      })),
      tracked_changes: (payload.tracked_changes || []).map((ch) => ({
        id: ch.id, short_id: ch.short_id, kind: ch.kind, content: ch.content,
        pathname: ch.pathname, line: ch.line,
        nearest_heading: ch.nearest_heading, user: ch.user,
      })),
      orphan_thread_ids: payload.orphan_thread_ids || [],
    };
  }

  function anchorByThread(payload) {
    const out = {};
    for (const c of payload.comments || []) {
      if (c && c.thread_id && !(c.thread_id in out)) out[c.thread_id] = c;
    }
    return out;
  }

  function messagesOf(thread) {
    if (!thread || typeof thread !== "object") return [];
    return (thread.messages || []).filter((m) => m && typeof m === "object");
  }

  function whoWrote(message) {
    const user = (message || {}).user || {};
    return String(user.name || user.email || (user.id || "someone").slice(0, 8));
  }

  const HEADING_CHARS = 55;

  function whereIs(anchor) {
    if (!anchor) return "not anchored to any text";
    const bits = [anchor.pathname || "?"];
    if (anchor.line) bits.push(`line ${anchor.line}`);
    const fl = anchor.enclosing_float;
    if (fl && fl.kind) {
      const name = fl.kind[0].toUpperCase() + fl.kind.slice(1);
      bits.push(fl.number ? `${name} ${fl.number}` : `an unnumbered ${fl.kind}`);
    } else if (anchor.nearest_heading) {
      let head = String(anchor.nearest_heading).split(/\s+/).filter(Boolean).join(" ");
      if (head.length > HEADING_CHARS) head = `${head.slice(0, HEADING_CHARS).trimEnd()}…`;
      bits.push(`§ ${head}`);
    }
    return bits.join(", ");
  }

  function compareExports(oldPayload, newPayload) {
    const oldProject = (oldPayload.project || {}).id;
    const newProject = (newPayload.project || {}).id;
    if (oldProject && newProject && oldProject !== newProject) {
      return {
        comparable: false,
        reason: `The previous export was a different paper (${oldProject}), so there is nothing to compare.`,
        newComments: [], newReplies: [], edited: [], resolved: [],
        reopened: [], gone: [], newChanges: [], filtersDiffer: false,
      };
    }

    const out = {
      comparable: true, reason: "",
      previousPulledAt: oldPayload.pulled_at || null,
      filtersDiffer: JSON.stringify(oldPayload.filters_applied || {})
        !== JSON.stringify(newPayload.filters_applied || {}),
      newComments: [], newReplies: [], edited: [], resolved: [],
      reopened: [], gone: [], newChanges: [],
    };

    const oldThreads = oldPayload.threads || {};
    const newThreads = newPayload.threads || {};
    const oldAnchors = anchorByThread(oldPayload);
    const newAnchors = anchorByThread(newPayload);

    for (const [tid, thread] of Object.entries(newThreads)) {
      const anchor = newAnchors[tid];
      const msgs = messagesOf(thread);
      const first = msgs[0] || {};
      const before = oldThreads[tid];

      if (!before) {
        out.newComments.push({
          threadId: tid, shortId: (anchor || {}).short_id || null,
          where: whereIs(anchor), who: whoWrote(first),
          when: first.timestamp || null, text: first.content || "",
          anchoredText: (anchor || {}).anchored_text || "",
          replyCount: thread.reply_count || 0,
        });
        continue;
      }

      const seen = new Set(messagesOf(before).map((m) => m.id));
      const fresh = msgs.filter((m) => !seen.has(m.id));
      if (fresh.length) {
        out.newReplies.push({
          threadId: tid, shortId: (anchor || {}).short_id || null,
          where: whereIs(anchor), openedBy: whoWrote(first),
          openingText: first.content || "",
          replies: fresh.map((m) => ({
            who: whoWrote(m), when: m.timestamp || null, text: m.content || "",
          })),
        });
      }

      // An edited comment changes what you have to answer without ever
      // showing up as new, which is the quietest way to miss something.
      const was = new Map(messagesOf(before).map((m) => [m.id, m.content]));
      for (const m of msgs) {
        if (was.has(m.id) && was.get(m.id) !== m.content) {
          out.edited.push({
            threadId: tid, shortId: (anchor || {}).short_id || null,
            where: whereIs(anchor), who: whoWrote(m),
            was: was.get(m.id) || "", now: m.content || "",
          });
        }
      }

      if (Boolean(thread.resolved) && !Boolean(before.resolved)) {
        const by = thread.resolved_by || {};
        out.resolved.push({
          threadId: tid, shortId: (anchor || {}).short_id || null,
          where: whereIs(anchor), by: by.name || by.email || "",
          text: first.content || "",
        });
      } else if (Boolean(before.resolved) && !Boolean(thread.resolved)) {
        out.reopened.push({
          threadId: tid, shortId: (anchor || {}).short_id || null,
          where: whereIs(anchor), text: first.content || "",
        });
      }
    }

    // Filters decide what reaches the export at all. A thread hidden this
    // time has not gone anywhere, and saying so would be a lie.
    if (!out.filtersDiffer) {
      for (const [tid, thread] of Object.entries(oldThreads)) {
        if (tid in newThreads) continue;
        const first = messagesOf(thread)[0] || {};
        out.gone.push({
          threadId: tid, where: whereIs(oldAnchors[tid]),
          who: whoWrote(first), text: first.content || "",
        });
      }
    }

    const seenChanges = new Set((oldPayload.tracked_changes || []).map((c) => c.id));
    for (const ch of newPayload.tracked_changes || []) {
      if (!seenChanges.has(ch.id)) {
        out.newChanges.push({
          shortId: ch.short_id || null, kind: ch.kind, content: ch.content || "",
          where: whereIs(ch), who: (ch.user || {}).name || (ch.user || {}).email || "",
        });
      }
    }

    return out;
  }

  function sinceShortIds(since) {
    const ids = (rows) => rows.map((r) => r.shortId).filter(Boolean);
    return {
      new_comments: ids(since.newComments),
      new_replies: ids(since.newReplies),
      edited: ids(since.edited),
      resolved: ids(since.resolved),
      reopened: ids(since.reopened),
      new_tracked_changes: ids(since.newChanges),
      gone_thread_ids: since.gone.map((r) => r.threadId),
    };
  }

  function sinceSummary(since) {
    if (!since.comparable) return since.reason;
    const bits = [
      [since.newComments.length, "new comment"],
      [since.newReplies.length, "thread with new replies"],
      [since.edited.length, "edited comment"],
      [since.resolved.length, "newly resolved"],
      [since.reopened.length, "reopened"],
      [since.gone.length, "gone"],
      [since.newChanges.length, "new tracked change"],
    ];
    const said = bits.filter(([n]) => n).map(([n, word]) => `${n} ${word}${n === 1 ? "" : "s"}`);
    if (!said.length) return "Nothing has changed since the previous export.";
    return `Since the previous export: ${said.join(", ")}.`;
  }


  function renderSinceMarkdown(since, projectTitle) {
    // Deliberately the same document since.py writes, so the two exports read
    // alike whichever produced them.
    const out = [`# What is new — ${projectTitle}`, ""];
    if (!since.comparable) {
      out.push(since.reason, "");
      return out.join("\n");
    }
    out.push("Compared with the previous export of this paper.", "",
             sinceSummary(since), "");
    const anything = since.newComments.length || since.newReplies.length
      || since.edited.length || since.resolved.length || since.reopened.length
      || since.gone.length || since.newChanges.length;
    const caveat = "Deletions are not listed. This export used different "
      + "filters from the previous one, so a comment missing from it may only "
      + "be filtered out rather than gone.";
    if (!anything) {
      out.push("Every comment in the export is one you have already seen.", "");
      if (since.filtersDiffer) out.push(caveat, "");
      return out.join("\n");
    }

    out.push("Short ids like `C012` are the ones in the Markdown from this run. "
      + "They shift when comments are added above them, so an id here will not "
      + "match the same comment in an older export.", "");

    const quote = (text, limit = 400) => {
      const t = String(text || "").trim();
      if (!t) return "> _(empty)_";
      const clipped = t.length > limit ? `${t.slice(0, limit).trimEnd()} …` : t;
      return clipped.split("\n").map((l) => (l.trim() ? `> ${l}` : ">")).join("\n");
    };
    const oneLine = (text, limit = 160) => {
      const t = String(text || "").split(/\s+/).filter(Boolean).join(" ");
      if (!t) return "_(empty)_";
      return t.length > limit ? `${t.slice(0, limit).trimEnd()} …` : t;
    };
    const head = (n, one, many) => `## ${n} ${n === 1 ? one : many}`;
    const title = (row) => (row.shortId ? `### ${row.shortId} — ${row.where}` : `### ${row.where}`);

    if (since.newComments.length) {
      out.push(head(since.newComments.length, "new comment", "new comments"), "");
      for (const c of since.newComments) {
        out.push(title(c), "", c.who + (c.when ? `, ${c.when}` : ""), "");
        if (c.anchoredText) out.push(`On: **${c.anchoredText.trim()}**`, "");
        out.push(quote(c.text), "");
      }
    }
    if (since.newReplies.length) {
      out.push(head(since.newReplies.length, "thread with new replies",
                    "threads with new replies"), "");
      for (const t of since.newReplies) {
        out.push(title(t), "", `${t.openedBy} originally wrote:`, "",
                 quote(t.openingText, 200), "");
        for (const r of t.replies) {
          out.push(`**${r.who}${r.when ? `, ${r.when}` : ""}**`, "", quote(r.text), "");
        }
      }
    }
    if (since.edited.length) {
      out.push(head(since.edited.length, "comment was edited", "comments were edited"), "");
      for (const e of since.edited) {
        out.push(title(e), "", `${e.who} changed it.`, "", "It said:", "",
                 quote(e.was, 200), "", "It now says:", "", quote(e.now, 200), "");
      }
    }
    if (since.resolved.length) {
      out.push(head(since.resolved.length, "comment was marked resolved",
                    "comments were marked resolved"), "");
      for (const r of since.resolved) {
        out.push(`- ${r.shortId ? `\`${r.shortId}\` ` : ""}${r.where}`
          + `${r.by ? `, resolved by ${r.by}` : ""} — ${oneLine(r.text)}`);
      }
      out.push("");
    }
    if (since.reopened.length) {
      out.push(head(since.reopened.length, "comment was reopened", "comments were reopened"), "");
      for (const r of since.reopened) {
        out.push(`- ${r.shortId ? `\`${r.shortId}\` ` : ""}${r.where} — ${oneLine(r.text)}`);
      }
      out.push("");
    }
    if (since.gone.length) {
      out.push(head(since.gone.length, "comment is gone", "comments are gone"), "",
        "These were in the previous export and are not in this one. Usually that "
        + "means somebody deleted the thread, or deleted the text it was attached to.", "");
      for (const g of since.gone) {
        out.push(`- ${g.where}, from ${g.who} — ${oneLine(g.text)}`);
      }
      out.push("");
    }
    if (since.newChanges.length) {
      out.push(head(since.newChanges.length, "new tracked change", "new tracked changes"), "");
      for (const ch of since.newChanges) {
        out.push(`- ${ch.shortId ? `\`${ch.shortId}\` ` : ""}${ch.kind}`
          + `${ch.who ? `, ${ch.who}` : ""}, ${ch.where} — ${oneLine(ch.content, 120)}`);
      }
      out.push("");
    }
    if (since.filtersDiffer) out.push(caveat, "");
    return out.join("\n");
  }

  function assembleExport({
    projectId,
    projectTitle,
    language = "en",
    rawThreads,
    resolvedIds = [],
    rangesPayload = null,
    docTexts = {},
    docIdToPath = {},
    rootDocId = null,
    includeResolved = true,
    includeChanges = true,
  }) {
    const allThreads = parseThreads(rawThreads, resolvedIds);
    const userMap = buildUserMap(rawThreads);
    const anchored = [];
    const trackedChanges = [];
    const referencedThreadIds = new Set();

    for (const entry of documentRanges(rangesPayload)) {
      const text = docTexts[entry.docId];
      if (typeof text !== "string") continue;
      const pathname = docIdToPath[entry.docId] || `<unknown-${entry.docId}>`;
      const lineStarts = buildLineStarts(text);
      const headings = findHeadings(text, lineStarts);

      for (const rawComment of entry.comments) {
        const operation = rawComment?.op || {};
        const threadId = operation.t || rawComment?.t;
        if (!threadId) continue;
        const anchoredText = String(operation.c || "");
        const resolved = resolveAnchor(text, lineStarts, Number(operation.p) || 0, anchoredText);
        anchored.push({
          shortId: "",
          threadId: String(threadId),
          docId: entry.docId,
          pathname,
          offset: resolved.offset,
          anchoredText,
          line: resolved.line,
          column: resolved.column,
          nearestHeading: nearestHeading(headings, resolved.line),
          enclosingFloat: enclosingFloat(findFloats(text, lineStarts), resolved.offset),
          stale: resolved.stale,
          context: extractContext(text, resolved.offset, anchoredText, resolved.line),
        });
        referencedThreadIds.add(String(threadId));
      }

      if (includeChanges) {
        for (const rawChange of entry.changes) {
          const operation = rawChange?.op || {};
          const metadata = rawChange?.metadata || {};
          let kind = null;
          let content = "";
          if (Object.prototype.hasOwnProperty.call(operation, "i")) {
            kind = "insertion";
            content = String(operation.i || "");
          } else if (Object.prototype.hasOwnProperty.call(operation, "d")) {
            kind = "deletion";
            content = String(operation.d || "");
          }
          if (!kind) continue;
          const rawOffset = Number(operation.p) || 0;
          const resolved = resolveAnchor(text, lineStarts, rawOffset, kind === "insertion" ? content : "");
          const userId = metadata.user_id ? String(metadata.user_id) : "";
          trackedChanges.push({
            shortId: "",
            id: String(rawChange?.id || rawChange?._id || ""),
            docId: entry.docId,
            pathname,
            kind,
            content,
            offset: rawOffset,
            line: resolved.line,
            column: resolved.column,
            nearestHeading: nearestHeading(headings, resolved.line),
            user: userMap[userId] || { id: userId, name: null, email: null },
            timestampMs: toMilliseconds(metadata.ts),
            context: kind === "insertion"
              ? extractContext(text, resolved.offset, content, resolved.line)
              : deletionContext(text, rawOffset, content, resolved.line),
          });
        }
      }
    }

    anchored.sort((left, right) =>
      left.pathname.localeCompare(right.pathname) || left.line - right.line || left.column - right.column || left.offset - right.offset
    );
    anchored.forEach((comment, index) => { comment.shortId = `C${String(index + 1).padStart(3, "0")}`; });
    trackedChanges.sort((left, right) =>
      left.pathname.localeCompare(right.pathname) || left.line - right.line || left.column - right.column || left.offset - right.offset
    );
    trackedChanges.forEach((change, index) => { change.shortId = `T${String(index + 1).padStart(3, "0")}`; });

    // ---- Read the whole paper in document order ----
    //
    // Everything above worked file by file, which is not how LaTeX reads a
    // project. Redo the headings and the float numbers over the spliced
    // document, so a comment in an included file gets the section it is
    // actually under and figures are numbered straight through.
    //
    // If any included file is missing, no number is claimed at all: a missing
    // number sends nobody anywhere, a wrong one sends them to the wrong
    // figure. Same rule as _apply_document_order in export.py.
    applyDocumentOrder({ anchored, trackedChanges, docTexts, docIdToPath, rootDocId });

    const visibleComments = anchored.filter((comment) => {
      const thread = allThreads[comment.threadId];
      return includeResolved || !thread?.resolved;
    });
    const orphanThreads = Object.values(allThreads).filter((thread) =>
      !referencedThreadIds.has(thread.id) && (includeResolved || !thread.resolved)
    );
    const visibleThreadIds = new Set([
      ...visibleComments.map((comment) => comment.threadId),
      ...orphanThreads.map((thread) => thread.id),
    ]);
    const visibleThreads = {};
    for (const threadId of [...visibleThreadIds].sort()) {
      if (allThreads[threadId]) visibleThreads[threadId] = serializeThread(allThreads[threadId], userMap);
    }

    const files = [];
    const allPaths = new Set([
      ...visibleComments.map((comment) => comment.pathname),
      ...trackedChanges.map((change) => change.pathname),
    ]);
    for (const pathname of [...allPaths].sort()) {
      const docId = Object.keys(docIdToPath).find((id) => docIdToPath[id] === pathname) || null;
      files.push({
        pathname,
        doc_id: docId,
        comment_count: visibleComments.filter((comment) => comment.pathname === pathname).length,
        change_count: trackedChanges.filter((change) => change.pathname === pathname).length,
        // The Python export has always written these, and this file's own
        // agent brief below promises them. They were simply missing.
        comment_short_ids: visibleComments.filter((comment) => comment.pathname === pathname).map((comment) => comment.shortId),
        change_short_ids: trackedChanges.filter((change) => change.pathname === pathname).map((change) => change.shortId),
      });
    }

    const serializedComments = visibleComments.map((comment) => {
      const messages = visibleThreads[comment.threadId]?.messages || [];
      return {
        short_id: comment.shortId,
        thread_id: comment.threadId,
        doc_id: comment.docId,
        pathname: comment.pathname,
        line: comment.line,
        col: comment.column,
        offset: comment.offset,
        nearest_heading: comment.nearestHeading,
        enclosing_float: comment.enclosingFloat
          ? {
            kind: comment.enclosingFloat.kind,
            number: comment.enclosingFloat.number,
            label: comment.enclosingFloat.label,
            caption: comment.enclosingFloat.caption,
          }
          : null,
        anchored_text: comment.anchoredText,
        stale: comment.stale,
        created_at: messages[0]?.timestamp || null,
        last_activity_at: messages.at(-1)?.timestamp || null,
        reply_count: visibleThreads[comment.threadId]?.reply_count || 0,
        context: comment.context ? {
          line: comment.context.line,
          before: comment.context.before,
          anchor: comment.context.anchor,
          after: comment.context.after,
          truncated_before: comment.context.truncatedBefore,
          truncated_after: comment.context.truncatedAfter,
        } : null,
      };
    });
    const serializedChanges = trackedChanges.map((change) => ({
      short_id: change.shortId,
      id: change.id,
      doc_id: change.docId,
      pathname: change.pathname,
      kind: change.kind,
      content: change.content,
      line: change.line,
      col: change.column,
      offset: change.offset,
      nearest_heading: change.nearestHeading,
      user: change.user,
      timestamp: isoTimestamp(change.timestampMs),
      context: change.context ? {
        line: change.context.line,
        before: change.context.before,
        anchor: change.context.anchor,
        after: change.context.after,
        truncated_before: change.context.truncatedBefore,
        truncated_after: change.context.truncatedAfter,
      } : null,
    }));

    const threadValues = Object.values(visibleThreads);
    const reviewerKeys = new Set();
    for (const thread of threadValues) {
      for (const message of thread.messages) {
        const user = message.user || {};
        const key = user.id || user.email || user.name;
        if (key) reviewerKeys.add(key);
      }
    }

    const payload = {
      schema_version: SCHEMA_VERSION,
      tool_version: TOOL_VERSION,
      report_language: language === "zh" ? "zh" : "en",
      project: { id: projectId, title: projectTitle || projectId },
      pulled_at: new Date().toISOString(),
      summary: {
        thread_count: threadValues.length,
        open_count: threadValues.filter((thread) => !thread.resolved).length,
        resolved_count: threadValues.filter((thread) => thread.resolved).length,
        tracked_change_count: serializedChanges.length,
        stale_anchor_count: serializedComments.filter((comment) => comment.stale).length,
        file_count: files.length,
        reviewer_count: reviewerKeys.size,
      },
      threads: visibleThreads,
      files,
      comments: serializedComments,
      tracked_changes: serializedChanges,
      orphan_thread_ids: orphanThreads.map((thread) => thread.id).sort(),
    };

    return {
      payload,
      markdown: renderMarkdown(payload),
      jsonl: renderJsonLines(payload),
      responseLetter: renderResponseLetter(payload),
    };
  }

  return {
    SCHEMA_VERSION,
    TOOL_VERSION,
    assembleExport,
    buildLineStarts,
    documentRanges,
    findHeadings,
    findIncludes,
    resolveInclude,
    flattenFiles,
    nearestHeading,
    normalizeWhitespace,
    offsetToLineColumn,
    parseThreads,
    renderJsonLines,
    buildSheetRows,
    sinceSnapshot,
    compareExports,
    sinceShortIds,
    sinceSummary,
    renderSinceMarkdown,
    COMMENT_COLUMNS,
    REPLY_COLUMNS,
    CHANGE_COLUMNS,
    renderMarkdown,
    renderAgentsBrief,
    renderResponseLetter,
    resolveAnchor,
    toMilliseconds,
  };
});
